<?php
/**
 * Skrine: generated from the design by wordpress-theme/build.js. The wording inside <main> is the page's content in WordPress.
 */
?><!DOCTYPE html>
<html lang="en">
<head>
  <base href="<?php echo esc_url( home_url( '/' ) ); ?>">
  <script>
  /* With <base> at the site root, "#section" links would point at the home page. Keep them on this page. */
  document.addEventListener("click", function (e) {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey) return;
    var a = e.target.closest && e.target.closest("a[href^='#']");
    if (!a) return;
    e.preventDefault();
    var id = a.getAttribute("href").slice(1);
    if (!id) return;
    var t = document.getElementById(decodeURIComponent(id));
    if (t) { t.scrollIntoView({ behavior: "smooth", block: "start" }); history.pushState(null, "", location.pathname + location.search + "#" + id); }
  });
  </script>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Karla:wght@300;400;500;600;700&family=Merriweather:wght@300;400;700;900&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/style.css">
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/insights.css">
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/article.css">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/favicon-32.png">
  <link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/favicon-192.png">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/apple-touch-icon.png">
  <?php wp_head(); ?>
</head>
<body class="page-inner" data-life="dragons">
  <?php skrine_header( 'is-scrolled' ); ?>

  <div class="ar-progress" aria-hidden="true"><span id="arProgress"></span></div>

  <main class="page-main ar-main nw-main" id="article">
<?php skrine_page_content( 'life-story' ); ?>
  </main>

  <!-- ===== Photo viewer ===== -->
  <dialog class="nw-lightbox" id="nwLightbox" aria-label="Photo viewer">
    <button type="button" class="nw-lb-close" data-close aria-label="Close"><i class="fa-solid fa-xmark" aria-hidden="true"></i></button>
    <button type="button" class="nw-lb-nav nw-lb-prev" id="nwPrev" aria-label="Previous photo"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i></button>
    <figure class="nw-lb-stage"><img id="nwLbImg" alt=""><figcaption id="nwLbCount"></figcaption></figure>
    <button type="button" class="nw-lb-nav nw-lb-next" id="nwNext" aria-label="Next photo"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i></button>
  </dialog>


  <?php skrine_footer( '' ); ?>

  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/main.js"></script>
  <?php skrine_data( 'people', array( 'people-data.js' ) ); ?>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/people-links.js"></script>
  <?php skrine_data( 'profiles', array( 'profiles-data.js' ) ); ?>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/life-data.js"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/life-full-data.js"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/article-common.js"></script>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/life-story.js"></script>
  <?php wp_footer(); ?>
</body>
</html>
