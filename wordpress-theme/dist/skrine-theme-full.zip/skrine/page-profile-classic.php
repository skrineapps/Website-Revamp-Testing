<?php
/**
 * Skrine: generated from the design by wordpress-theme/build.js. The wording inside <main> is the page's content in WordPress.
 */
?><!DOCTYPE html>
<html lang="en">
<head>
  <base href="<?php echo esc_url( home_url( '/' ) ); ?>">
  <script>
  /* With <base> at the site root, "#section" links would point at the home page. Keep them on this page. */
  document.addEventListener("click", function (e) {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey) return;
    var a = e.target.closest && e.target.closest("a[href^='#']");
    if (!a) return;
    e.preventDefault();
    var id = a.getAttribute("href").slice(1);
    if (!id) return;
    var t = document.getElementById(decodeURIComponent(id));
    if (t) { t.scrollIntoView({ behavior: "smooth", block: "start" }); history.pushState(null, "", location.pathname + location.search + "#" + id); }
  });
  </script>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>People | Skrine</title>
  <meta name="description" content="Skrine partner and consultant profiles.">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Karla:wght@300;400;500;600;700&family=Merriweather:wght@300;400;700;900&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/style.css">
  <link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() ); ?>/css/profile-classic.css">
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/favicon-32.png">
  <link rel="icon" type="image/png" sizes="192x192" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/favicon-192.png">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( get_template_directory_uri() ); ?>/images/apple-touch-icon.png">
  <?php wp_head(); ?>
</head>
<body class="page-inner pc-page">
  <!-- ============ HEADER ============ -->
  <header class="site-header is-scrolled" id="siteHeader">
    <div class="header-inner">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand" aria-label="Skrine home">
        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/skrine-logo.png" alt="Skrine" class="brand-logo" width="475" height="94">
      </a>

      <nav class="main-nav" id="primaryNav" aria-label="Primary">
        <ul class="nav-list">
          <li class="nav-item">
            <a href="people.html" class="nav-link" aria-current="page">People</a>
          </li>

          <li class="nav-item has-menu">
            <button type="button" class="nav-link nav-trigger" aria-expanded="false"  aria-controls="menu-capabilities">
              Capabilities <i class="fa-solid fa-chevron-down nav-caret" aria-hidden="true"></i>
            </button>
            <ul class="nav-menu" id="menu-capabilities">
              <li><a href="capabilities.html">Practice Areas</a></li>
              <li><a href="sectors.html">Sectors</a></li>
            </ul>
          </li>

          <li class="nav-item has-menu">
            <button type="button" class="nav-link nav-trigger" aria-expanded="false" aria-controls="menu-insights">
              Insights <i class="fa-solid fa-chevron-down nav-caret" aria-hidden="true"></i>
            </button>
            <ul class="nav-menu" id="menu-insights">
              <li><a href="alerts.html">Alerts</a></li>
              <li><a href="articles.html">Articles</a></li>
              <li><a href="publications.html">Publications</a></li>
              <li><a href="news-events.html">News &amp; Events</a></li>
            </ul>
          </li>

          <li class="nav-item has-menu">
            <a href="careers.html" class="nav-link">Career</a>
            <button type="button" class="nav-caret-btn nav-trigger" aria-expanded="false" aria-controls="menu-career" aria-label="Career menu">
              <i class="fa-solid fa-chevron-down nav-caret" aria-hidden="true"></i>
            </button>
            <ul class="nav-menu" id="menu-career">
              <li><a href="professional-development.html">Professional Development</a></li>
              <li><a href="social-responsibility.html">Social Responsibility</a></li>
              <li><a href="sports-social.html">Sports &amp; Social</a></li>
              <li><a href="skrine-dragons.html">Skrine Dragons</a></li>
            </ul>
          </li>

          <li class="nav-item">
            <a href="contact.html" class="nav-link">Contact</a>
          </li>
        </ul>
      </nav>

      <button class="icon-btn search-toggle" id="searchToggle" aria-label="Search">
        <i class="fa-solid fa-magnifying-glass"></i>
      </button>

      <button class="icon-btn nav-toggle" id="navToggle" type="button" aria-expanded="false" aria-controls="primaryNav" aria-label="Open menu">
        <span></span><span></span><span></span>
      </button>
    </div>

    <form class="search-bar" id="searchBar" role="search" onsubmit="return false;">
      <input type="search" placeholder="Search people, practices, insights…" aria-label="Search the site">
      <button type="submit" aria-label="Submit search"><i class="fa-solid fa-arrow-right"></i></button>
    </form>
  </header>

  <main class="pc-main" id="profile">
<?php skrine_page_content( 'profile-classic' ); ?>
  </main>

  <!-- review aid: flip between the two profile designs -->
  <nav class="design-switch" aria-label="Profile design">
    <a href="profile.html" data-switch>Modern</a>
    <a href="profile-classic.html" data-switch aria-current="page">Classic</a>
  </nav>

  <!-- ============ FOOTER ============ -->
  <footer class="site-footer pc-footer">
    <div class="footer-inner">
      <div class="footer-member">
        <span class="member-label">Proud to be a<br>member of</span>
        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/lexmundi.svg" alt="Lex Mundi — Bringing the best together" class="member-logo">
      </div>

      <div class="footer-connect">
        <span>Connect with us</span>
        <a href="#" aria-label="Email"><i class="fa-regular fa-envelope"></i></a>
        <a href="#" aria-label="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
        <a href="#" aria-label="WeChat"><i class="fa-brands fa-weixin"></i></a>
      </div>
    </div>
    <p class="footer-legal">
      © 1963 – <span id="year">2026</span> Skrine. All rights reserved
      <span class="sep">|</span> <a href="#">Disclaimer</a>
      <span class="sep">|</span> <a href="#">PDPA Notice</a>
    </p>
  </footer>

  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/main.js"></script>
  <?php skrine_data( 'people', array( 'people-data.js' ) ); ?>
  <?php skrine_data( 'profiles', array( 'profiles-data.js' ) ); ?>
  <?php skrine_data( 'news', array( 'news-data.js' ) ); ?>
  <script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/profile-classic.js"></script>
  <?php wp_footer(); ?>
</body>
</html>
