<?php
// Fallback template: show the home page design.
require get_template_directory() . '/front-page.php';
